package com.example.task_manager_sqlite;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TaskManagerSeleniumTest {

    @LocalServerPort
    private int port;

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    @AfterEach
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testAddTask() {
        // Open app page
        driver.get("http://localhost:" + port + "/");

        // Enter task name
        WebElement taskInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Enter task name']")));
        taskInput.sendKeys("New Selenium Task");

        // Click "Add Task" button
        WebElement addButton = driver.findElement(By.xpath("//button[text()='Add Task']"));
        addButton.click();

        // Wait for table to refresh by waiting for the last row to contain our task
        boolean taskFound = false;
        for (int i = 0; i < 10; i++) { // retry up to 10 times
            try {
                List<WebElement> tasks = driver.findElements(
                        By.xpath("//table/tbody/tr/td[contains(text(), 'New Selenium Task')]"));
                if (!tasks.isEmpty()) {
                    taskFound = true;
                    break;
                }
                Thread.sleep(1000); // wait 1 second before retry
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        assertTrue(taskFound, "New task should be displayed in the table");
    }
}
