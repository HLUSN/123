package com.example.task_manager_sqlite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagerSqliteApplicationTests {

	@Test
	void contextLoads() {
	}

}
