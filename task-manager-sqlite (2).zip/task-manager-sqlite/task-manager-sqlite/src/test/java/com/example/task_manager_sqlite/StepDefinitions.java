package com.example.task_manager_sqlite;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class StepDefinitions {

    @LocalServerPort
    private int port;

    @Autowired
    private WebDriver driver;

    @Autowired
    private WebDriverWait wait;

    @Given("I am on the tasks page")
    public void i_am_on_the_tasks_page() {
        driver.get("http://localhost:" + port + "/tasks");
    }

    @When("I enter {string} into the task field")
    public void i_enter_into_the_task_field(String taskName) {
        WebElement taskInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Enter task name']")));
        taskInput.sendKeys(taskName);
    }

    @When("I click the {string} button")
    public void i_click_the_button(String buttonText) {
        WebElement button = driver.findElement(By.xpath("//button[text()='" + buttonText + "']"));
        button.click();
    }
    // ... Implement all other steps from the feature file
}